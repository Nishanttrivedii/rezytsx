export const sampleData = [
    {
        "UNIT": "UNIT 01",
        "DEVICES": [
            {
                "DDector":"Smoke Detector",
                "DTemp"  :"Temperature/Humidity"
            }
        ],
        "INSTALLED_DATE": "02-06-2024",
        "READINGS": [
            {
                "REDETAIL": "Temperature: 123",
                "HUDETAIL":"Humidity: 84%"
            },
        ],
        "TENANT_NAME": "Tenant Name"
    },
    {
        "UNIT": "UNIT 01",
        "DEVICES": [
            {
                "DDector":"Smoke Detector",
                "DTemp"  :"Temperature/Humidity"
            }
        ],
        "INSTALLED_DATE": "02-06-2024",
        "READINGS": [
            {
                "REDETAIL": "Temperature: 25.2",
                "HUDETAIL":"Humidity: 84%"
            },
        ],
        "TENANT_NAME": "Tenant Name"
    },
    {
        "UNIT": "UNIT 01",
        "DEVICES": [
            {
                "DDector":"Smoke Detector",
                "DTemp"  :"Temperature/Humidity"
            }
        ],
        "INSTALLED_DATE": "02-06-2024",
        "READINGS": [
            {
                "REDETAIL": "Temperature: 25.2",
                "HUDETAIL":"Humidity: 84%"
            },
        ],
        "TENANT_NAME": "Tenant Name"
    },
    {
        "UNIT": "UNIT 01",
        "DEVICES": [
            {
                "DDector":"Smoke Detector",
                "DTemp"  :"Temperature/Humidity"
            }
        ],
        "INSTALLED_DATE": "02-06-2024",
        "READINGS": [
            {
                "REDETAIL": "Temperature: 25.2",
                "HUDETAIL":"Humidity: 84%"
            },
        ],
        "TENANT_NAME": "Tenant Name"
    },
    {
        "UNIT": "UNIT 01",
        "DEVICES": [
            {
                "DDector":"Smoke Detector",
                "DTemp"  :"Temperature/Humidity"
            }
        ],
        "INSTALLED_DATE": "02-06-2024",
        "READINGS": [
            {
                "REDETAIL": "Temperature: 25.2",
                "HUDETAIL":"Humidity: 84%"
            },
        ],
        "TENANT_NAME": "Tenant Name"
    },
    {
        "UNIT": "UNIT 01",
        "DEVICES": [
            {
                "DDector":"Smoke Detector",
                "DTemp"  :"Temperature/Humidity"
            }
        ],
        "INSTALLED_DATE": "02-06-2024",
        "READINGS": [
            {
                "REDETAIL": "Temperature: 25.2",
                "HUDETAIL":"Humidity: 84%"
            },
        ],
        "TENANT_NAME": "Tenant Name"
    },
    {
        "UNIT": "UNIT 01",
        "DEVICES": [
            {
                "DDector":"Smoke Detector",
                "DTemp"  :"Temperature/Humidity"
            }
        ],
        "INSTALLED_DATE": "02-06-2024",
        "READINGS": [
            {
                "REDETAIL": "Temperature: 25.2",
                "HUDETAIL":"Humidity: 84%"
            },
        ],
        "TENANT_NAME": "Tenant Name"
    },
    {
        "UNIT": "UNIT 01",
        "DEVICES": [
            {
                "DDector":"Smoke Detector",
                "DTemp"  :"Temperature/Humidity"
            }
        ],
        "INSTALLED_DATE": "02-06-2024",
        "READINGS": [
            {
                "REDETAIL": "Temperature: 25.2",
                "HUDETAIL":"Humidity: 84%"
            },
        ],
        "TENANT_NAME": "Tenant Name"
    },
    {
        "UNIT": "UNIT 01",
        "DEVICES": [
            {
                "DDector":"Smoke Detector",
                "DTemp"  :"Temperature/Humidity"
            }
        ],
        "INSTALLED_DATE": "02-06-2024",
        "READINGS": [
            {
                "REDETAIL": "Temperature: 25.2",
                "HUDETAIL":"Humidity: 84%"
            },
        ],
        "TENANT_NAME": "Tenant Name"
    },
    {
        "UNIT": "UNIT 01",
        "DEVICES": [
            {
                "DDector":"Smoke Detector",
                "DTemp"  :"Temperature/Humidity"
            }
        ],
        "INSTALLED_DATE": "02-06-2024",
        "READINGS": [
            {
                "REDETAIL": "Temperature: 25.2",
                "HUDETAIL":"Humidity: 84%"
            },
        ],
        "TENANT_NAME": "Tenant Name"
    },
]